# WeCARE - Life Coaching application

Spring Boot (REST) + MySQL backend with a browser UI served by the same app. Open **http://localhost:52866** once it has started.

You need a **Java JDK 8 or newer** (JDK 17 recommended, free from https://adoptium.net). Maven is downloaded automatically by the run scripts.

## Do I have to install MySQL? No - pick any one option

| Option | What you need | Command |
|---|---|---|
| **A. No database install** (quickest) | JDK only | Windows: `run.bat` - Mac/Linux: `./run.sh` (default) |
| **B. Docker** (real MySQL, nothing else to install) | Docker Desktop | `docker compose up --build` |
| **C. Your own MySQL 8** | JDK + MySQL running | `run.bat mysql` / `./run.sh mysql` (see below) |

Option A keeps data in a local `data/` folder (an embedded database in MySQL mode). Options B and C use real MySQL.

### Option C - using a MySQL you already have
The `wecare` database and all tables are created automatically. Tell the app how to connect (defaults: `localhost:3306`, user `root`, password `root`):

- Windows: `set DB_PASSWORD=your_mysql_password` then `run.bat mysql`
- Mac/Linux: `DB_PASSWORD=your_mysql_password ./run.sh mysql`
- Other settings: `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USERNAME` - or edit `src/main/resources/application.properties`.

### Connection reliability
Start-up keeps retrying the database for 60 seconds (so MySQL may still be booting), the connection pool validates and recycles connections, and the JDBC URL sets SSL/time-zone/key-retrieval options that avoid the usual MySQL 8 errors.
No MySQL on port 3306 but Docker available? `docker compose up -d db`, then run with `DB_PORT=3307 DB_PASSWORD=wecare123`.

## Demo data
On the first start (tables empty) 6 coaches, 2 users and 4 upcoming appointments are inserted. Ids come from the time-based id generators and the appointment dates are calculated from today, so the ids are printed in the console / `wecare.log` at start-up. Password for every demo account: `12345`. Coach ids are also shown on the user home page. You can always sign up as a new user or coach.

## Emails
Booking / reschedule / cancel mails are sent through Gmail SMTP when you provide credentials: `MAIL_USERNAME` (Gmail address) and `MAIL_PASSWORD`. Google no longer offers "less secure app access" - turn on 2-Step Verification and create an **App Password** to use as `MAIL_PASSWORD`. Without credentials the app works normally and just logs that the mail could not be sent.

## REST endpoints
| | |
|---|---|
| `POST /api/users` / `POST /api/users/login` / `GET /api/users/{id}` / `GET /api/users/{id}/bookings` | sign up, login, profile, upcoming appointments |
| `POST /api/coaches` / `POST /api/coaches/login` / `GET /api/coaches` / `GET /api/coaches/{id}` / `GET /api/coaches/{id}/bookings` | sign up, login, all coaches, profile, schedule |
| `POST /api/bookings` / `POST /api/bookings/{id}/reschedule` / `POST /api/bookings/{id}/cancel` / `GET /api/bookings/{id}` | book, reschedule, cancel, find |

## Project layout
`com.infosys.{controller, service, repository, entity, dto, exception, utility}` plus `config.DataLoader` (demo data). Tables: `usertable`, `coachtable`, `bookingtable`.
The UI (plain HTML/CSS/JS) is in `src/main/resources/static`. Because the REST API allows cross-origin calls, you can also build the UI in Angular / React / Vue and point it at `http://localhost:52866/api`.
