package com.infosys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

@SpringBootTest
@ActiveProfiles("h2")
@TestPropertySource(properties = { "spring.datasource.url=jdbc:h2:mem:wecaretest;MODE=MySQL",
		"wecare.seed.enabled=false" })
class WeCareApplicationTests {

	@Test
	void contextLoads() {
	}
}
