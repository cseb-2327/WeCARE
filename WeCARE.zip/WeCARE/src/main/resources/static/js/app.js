(function () {
  'use strict';

  // Same origin by default (Spring Boot serves this page). Set window.WECARE_API_BASE to use another host.
  const API = window.WECARE_API_BASE || '';
  const SLOTS = ['9 AM to 10 AM', '10 AM to 11 AM', '11 AM to 12 PM', '2 PM to 3 PM', '3 PM to 4 PM', '4 PM to 5 PM'];

  const view = document.getElementById('view');
  const nav = document.getElementById('nav');
  const brand = document.getElementById('brand');
  const modal = document.getElementById('modal');

  /* ------------------------------------------------------------ helpers */
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const pad = n => String(n).padStart(2, '0');
  const iso = d => d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  const addDays = (d, n) => { const x = new Date(d.getTime()); x.setDate(x.getDate() + n); return x; };
  const age = dob => {
    const b = new Date(dob + 'T00:00:00');
    if (isNaN(b.getTime())) return NaN;
    const t = new Date();
    let a = t.getFullYear() - b.getFullYear();
    const m = t.getMonth() - b.getMonth();
    if (m < 0 || (m === 0 && t.getDate() < b.getDate())) a--;
    return a;
  };

  const session = {
    get() { try { return JSON.parse(sessionStorage.getItem('wecare')) || null; } catch (e) { return null; } },
    set(v) { sessionStorage.setItem('wecare', JSON.stringify(v)); },
    clear() { sessionStorage.removeItem('wecare'); }
  };

  // The backend answers with plain text (ids), JSON (true / lists / DTOs) or {"message": "..."} for errors.
  async function api(method, path, body) {
    const opts = { method: method, headers: {} };
    if (body !== undefined) {
      opts.headers['Content-Type'] = 'application/json';
      opts.body = JSON.stringify(body);
    }
    let res;
    try {
      res = await fetch(API + path, opts);
    } catch (e) {
      throw new Error('Cannot reach the WeCARE server. Please make sure the application is running.');
    }
    const text = await res.text();
    let data = text;
    try { data = text === '' ? null : JSON.parse(text); } catch (e) { data = text; }
    if (data && typeof data === 'object' && !Array.isArray(data) && typeof data.message === 'string') {
      throw new Error(data.message);
    }
    if (!res.ok) {
      throw new Error(typeof data === 'string' && data ? data : 'Something went wrong. Please try again.');
    }
    return data;
  }

  const setView = html => { view.innerHTML = html; };
  const loading = () => setView('<p class="note">Loading...</p>');
  const goBack = href => `<a class="btn teal auto" href="${href}">&#8592; Go Back</a>`;
  const showMessage = (text, backHref) =>
    setView(`<div class="card dark msg"><p>${esc(text)}</p>${goBack(backHref)}</div>`);
  const run = fn => Promise.resolve().then(fn).catch(err => showMessage(err.message || 'Something went wrong.', '#/'));

  /* ------------------------------------------------------------ icons */
  const avatar = () => `<svg class="avatar" viewBox="0 0 120 120" role="img" aria-label="Profile picture">
    <defs><clipPath id="avclip"><circle cx="60" cy="60" r="57"/></clipPath></defs>
    <circle cx="60" cy="60" r="58" fill="#e6e6e6" stroke="#f0c4c4" stroke-width="2"/>
    <g clip-path="url(#avclip)">
      <path d="M12 125c3-28 22-38 48-38s45 10 48 38z" fill="#2b2b2b"/>
      <path d="M46 88l14 20 14-20z" fill="#fff"/>
      <path d="M56 92h8l3 20-7 6-7-6z" fill="#e8262b"/>
      <rect x="53" y="64" width="14" height="24" fill="#f2cfae"/>
      <ellipse cx="60" cy="46" rx="18" ry="21" fill="#f5d3b3"/>
      <path d="M41 44c-2-18 8-26 19-26s21 8 19 26c-5-9-33-9-38 0z" fill="#3a3a3a"/>
    </g></svg>`;
  const coachIcon = () => `<svg class="role-icon" viewBox="0 0 100 100" aria-hidden="true">
    <path d="M18 100c2-24 15-34 32-34s30 10 32 34z" fill="#3f7fb0"/>
    <ellipse cx="50" cy="42" rx="14" ry="17" fill="#f4f4f4"/>
    <path d="M32 38c0-15 8-24 18-24s18 9 18 24z" fill="#2f5575"/>
    <rect x="28" y="35" width="44" height="6" rx="3" fill="#2f5575"/>
    <circle cx="50" cy="82" r="4.5" fill="#f4f4f4"/></svg>`;
  const userIcon = () => `<svg class="role-icon" viewBox="0 0 100 100" aria-hidden="true">
    <path d="M14 100c2-24 16-34 34-34s32 10 34 34z" fill="#6b4a12"/>
    <path d="M40 68l8 14 8-14z" fill="#fff"/><path d="M45 72h6l2 18-5 4-5-4z" fill="#2d6cb5"/>
    <ellipse cx="48" cy="40" rx="14" ry="17" fill="#f5c9a0"/>
    <path d="M33 36c0-14 8-22 15-22s16 8 15 22c-4-7-26-7-30 0z" fill="#8a4b1a"/>
    <circle cx="76" cy="62" r="9" fill="none" stroke="#d9a42b" stroke-width="5"/>
    <path d="M70 69l-12 14" stroke="#d9a42b" stroke-width="5" stroke-linecap="round"/></svg>`;

  /* ------------------------------------------------------------ nav + router */
  function renderNav() {
    const s = session.get();
    let html = '';
    if (s) {
      html += `<a href="#/${s.role}/profile">View Profile</a>`;
      html += s.role === 'user'
        ? '<a href="#/user/appointments">My Appointments</a>'
        : '<a href="#/coach/home">My Schedules</a>';
    }
    html += '<span>&#9742; Call Us : 080 2233447</span>';
    if (s) html += '<a href="#/logout">Logout</a>';
    nav.innerHTML = html;
    brand.setAttribute('href', s ? `#/${s.role}/home` : '#/');
  }

  function closeModal() { modal.classList.add('hidden'); modal.innerHTML = ''; }

  function route() {
    const parts = (location.hash.replace(/^#/, '') || '/').split('/').filter(Boolean).map(decodeURIComponent);
    const a = parts[0], b = parts[1], c = parts[2];
    const s = session.get();
    renderNav();
    closeModal();
    window.scrollTo(0, 0);

    if (!a) return home();
    if (a === 'logout') { session.clear(); location.hash = '#/'; return; }
    if ((a === 'user' || a === 'coach') && b === 'signup') return signup(a);
    if ((a === 'user' || a === 'coach') && b === 'login') return login(a);

    if (a === 'user' || a === 'coach') {
      if (!s || s.role !== a) { location.hash = '#/'; return; }
      if (a === 'user') {
        if (b === 'home') return run(userHome);
        if (b === 'profile') return run(() => profile('user'));
        if (b === 'appointments') return run(appointments);
        if (b === 'book') return bookForm(c);
        if (b === 'reschedule') return rescheduleForm(c);
      } else {
        if (b === 'home') return run(coachSchedule);
        if (b === 'profile') return run(() => profile('coach'));
      }
    }
    home();
  }

  /* ------------------------------------------------------------ home */
  function home() {
    setView(`
      <h1 class="hero-title">We are at the heart of appropriate care</h1>
      <div class="role-cards">
        <div class="card dark role">${coachIcon()}
          <a class="btn teal" href="#/coach/login">Login as a Coach</a>
          <a class="btn teal" href="#/coach/signup">Join as a Coach</a></div>
        <div class="card dark role">${userIcon()}
          <a class="btn teal" href="#/user/login">Login as a User</a>
          <a class="btn teal" href="#/user/signup">Join as a User</a></div>
      </div>`);
  }

  /* ------------------------------------------------------------ validation */
  const V = {
    length: (min, max, label) => v => {
      const x = String(v || '').trim();
      if (!x) return `${label} is required`;
      if (x.length < min) return `${label} must be at least ${min} letters`;
      if (x.length > max) return `${label} must be at most ${max} letters`;
      return '';
    },
    digits: (n, label) => v => {
      const x = String(v || '').trim();
      if (!x) return `${label} is required`;
      return new RegExp('^[1-9][0-9]{' + (n - 1) + '}$').test(x) ? '' : `${label} must be ${n} digits`;
    },
    email: v => {
      const x = String(v || '').trim();
      if (!x) return 'Email is required';
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x) ? '' : 'Please enter a valid email';
    },
    dob: (min, max) => v => {
      if (!v) return 'Date of Birth is required';
      const a = age(v);
      if (isNaN(a)) return 'Please enter a valid date';
      if (a < min) return `Minimum age is ${min} years`;
      if (a > max) return `Maximum age is ${max} years`;
      return '';
    },
    gender: v => (v ? '' : 'Gender is required')
  };

  const val = (form, key) => form.elements[key].value;

  const FORMS = {
    user: {
      title: 'User Profile', icon: userIcon, endpoint: '/api/users', width: 'form-wide',
      fields: [
        { key: 'name', label: 'Name', type: 'text', validate: V.length(3, 50, 'Name') },
        { key: 'password', label: 'Password', type: 'password', validate: V.length(5, 10, 'Password') },
        { key: 'mobileNumber', label: 'Mobile Number', type: 'tel', validate: V.digits(10, 'Mobile Number') },
        { key: 'email', label: 'Email', type: 'email', validate: V.email },
        { key: 'dateOfBirth', label: 'Date of Birth', type: 'date', validate: V.dob(5, 100) },
        { key: 'gender', label: 'Gender', type: 'radio', validate: V.gender },
        { key: 'pincode', label: 'Pincode', type: 'tel', validate: V.digits(6, 'Pincode') },
        { key: 'city', label: 'City', type: 'text', validate: V.length(3, 20, 'City') },
        { key: 'state', label: 'State', type: 'text', validate: V.length(3, 20, 'State') },
        { key: 'country', label: 'Country', type: 'text', validate: V.length(3, 20, 'Country') }
      ],
      toDto: f => ({
        name: val(f, 'name').trim(), password: val(f, 'password'), mobileNumber: Number(val(f, 'mobileNumber')),
        email: val(f, 'email').trim(), dateOfBirth: val(f, 'dateOfBirth'), gender: val(f, 'gender'),
        pincode: Number(val(f, 'pincode')), city: val(f, 'city').trim(), state: val(f, 'state').trim(),
        country: val(f, 'country').trim()
      })
    },
    coach: {
      title: 'Life Coach Profile', icon: coachIcon, endpoint: '/api/coaches', width: 'form-narrow',
      fields: [
        { key: 'name', label: 'Name', type: 'text', validate: V.length(3, 50, 'Name') },
        { key: 'password', label: 'Password', type: 'password', validate: V.length(5, 10, 'Password') },
        { key: 'dateOfBirth', label: 'Date of Birth', type: 'date', validate: V.dob(20, 100) },
        { key: 'gender', label: 'Gender', type: 'radio', validate: V.gender },
        { key: 'mobileNumber', label: 'Mobile Number', type: 'tel', validate: V.digits(10, 'Mobile Number') },
        { key: 'speciality', label: 'Speciality', type: 'text', validate: V.length(10, 20, 'Speciality') }
      ],
      toDto: f => ({
        name: val(f, 'name').trim(), password: val(f, 'password'), dateOfBirth: val(f, 'dateOfBirth'),
        gender: val(f, 'gender'), mobileNumber: Number(val(f, 'mobileNumber')), speciality: val(f, 'speciality').trim()
      })
    }
  };

  const fieldHtml = f => {
    if (f.type === 'radio') {
      return `<div class="field"><label>${f.label}</label>
        <div class="radios"><label><input type="radio" name="${f.key}" value="M"> Male</label>
        <label><input type="radio" name="${f.key}" value="F"> Female</label></div>
        <span class="err" data-for="${f.key}"></span></div>`;
    }
    const extra = f.type === 'date' ? ` max="${iso(new Date())}"` : '';
    return `<div class="field"><label for="f_${f.key}">${f.label}</label>
      <input id="f_${f.key}" name="${f.key}" type="${f.type}" autocomplete="off"${extra}>
      <span class="err" data-for="${f.key}"></span></div>`;
  };

  function checkField(form, fields, key) {
    const f = fields.find(x => x.key === key);
    const msg = f.validate(val(form, key));
    form.querySelector(`.err[data-for="${key}"]`).textContent = msg;
    return msg;
  }

  /* ------------------------------------------------------------ sign up */
  function signup(role) {
    const def = FORMS[role];
    setView(`<form class="card dark ${def.width}" id="signupForm" novalidate>
      <h2><span class="ico">${def.icon()}</span>${def.title}</h2>
      <div class="grid2">${def.fields.map(fieldHtml).join('')}</div>
      <div class="form-actions"><button class="btn green" type="submit">Register</button></div>
      <p class="err form-err" id="formErr"></p></form>`);

    const form = document.getElementById('signupForm');
    form.addEventListener('focusout', e => {
      if (e.target.name && e.target.type !== 'radio') checkField(form, def.fields, e.target.name);
    });
    form.addEventListener('change', e => {
      if (e.target.type === 'radio') checkField(form, def.fields, e.target.name);
    });
    form.addEventListener('submit', async e => {
      e.preventDefault();
      let bad = 0;
      def.fields.forEach(f => { if (checkField(form, def.fields, f.key)) bad++; });
      if (bad) return;
      const btn = form.querySelector('button');
      btn.disabled = true;
      try {
        const id = await api('POST', def.endpoint, def.toDto(form));
        signupSuccess(role, id);
      } catch (err) {
        document.getElementById('formErr').textContent = err.message;
        btn.disabled = false;
      }
    });
  }

  function signupSuccess(role, id) {
    const isUser = role === 'user';
    setView(`<div class="big-msg"><div class="illus">${isUser ? userIcon() : coachIcon()}</div>
      <h2>${isUser ? 'Account created successfully' : 'You are a Coach now !'}</h2>
      <p>Your ${isUser ? 'User' : 'Coach'} Id is ${esc(id)}</p>
      <a class="btn blue" href="#/${role}/login">Login Now</a></div>`);
  }

  /* ------------------------------------------------------------ login */
  function login(role) {
    const isUser = role === 'user';
    setView(`<form class="card dark form-small" id="loginForm" novalidate>
      <h2><span class="ico">${isUser ? userIcon() : coachIcon()}</span>Login As ${isUser ? 'User' : 'Life Coach'}</h2>
      <input type="text" name="id" placeholder="${isUser ? 'User Id' : 'Coach Id'}" autocomplete="username">
      <span class="err" data-for="id"></span>
      <input type="password" name="password" placeholder="Password" autocomplete="current-password">
      <span class="err" data-for="password"></span>
      <div class="form-actions"><button class="btn blue" type="submit">Login</button></div>
      <p class="err form-err" id="formErr"></p></form>`);

    const form = document.getElementById('loginForm');
    const rules = {
      id: v => (String(v || '').trim() ? '' : (isUser ? 'User Id is required' : 'Coach Id is required')),
      password: V.length(5, 10, 'Password')
    };
    const check = key => {
      const msg = rules[key](val(form, key));
      form.querySelector(`.err[data-for="${key}"]`).textContent = msg;
      return msg;
    };
    form.addEventListener('focusout', e => { if (rules[e.target.name]) check(e.target.name); });
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const bad = [check('id'), check('password')].filter(Boolean).length;
      if (bad) return;
      const btn = form.querySelector('button');
      btn.disabled = true;
      try {
        const id = val(form, 'id').trim();
        const ok = await api('POST', isUser ? '/api/users/login' : '/api/coaches/login',
          { id: id, password: val(form, 'password') });
        if (ok === true) {
          session.set({ role: role, id: id });
          location.hash = isUser ? '#/user/home' : '#/coach/home';
        } else {
          document.getElementById('formErr').textContent = 'Incorrect password. Please try again.';
          btn.disabled = false;
        }
      } catch (err) {
        document.getElementById('formErr').textContent = err.message;
        btn.disabled = false;
      }
    });
  }

  /* ------------------------------------------------------------ user home: coaches */
  async function userHome() {
    loading();
    const coaches = (await api('GET', '/api/coaches')) || [];
    setView(`<div class="search"><input type="text" id="search" placeholder="Search for speciality" aria-label="Search for speciality"></div>
      <div class="coach-grid" id="coachGrid"></div>`);
    const grid = document.getElementById('coachGrid');
    const draw = q => {
      const list = coaches.filter(c => String(c.speciality || '').toLowerCase().includes(q.trim().toLowerCase()));
      grid.innerHTML = list.length ? list.map(c => `<div class="card light coach">${avatar()}
          <div><h3>${esc(c.name)}</h3><div class="id">${esc(c.coachId)}</div>
          <div class="meta">Mobile No:${esc(c.mobileNumber)}</div>
          <div class="meta">Speciality : ${esc(c.speciality)}</div>
          <a class="btn blue" href="#/user/book/${encodeURIComponent(c.coachId)}">Book an Appointment</a></div></div>`).join('')
        : '<p class="note">No life coaches found for that speciality.</p>';
    };
    draw('');
    document.getElementById('search').addEventListener('input', e => draw(e.target.value));
  }

  /* ------------------------------------------------------------ profile */
  async function profile(role) {
    loading();
    const s = session.get();
    const isUser = role === 'user';
    const p = await api('GET', (isUser ? '/api/users/' : '/api/coaches/') + encodeURIComponent(s.id));
    if (!p) { showMessage('Profile not found.', '#/'); return; }
    const details = isUser
      ? `<div class="meta">Date of Birth : ${esc(p.dateOfBirth)}</div>
         <div class="meta">Email Id : ${esc(p.email)}</div>
         <div class="meta">Mobile No: ${esc(p.mobileNumber)}</div>
         <div class="meta">Address : ${esc(p.city)}, ${esc(p.state)}, ${esc(p.country)}</div>
         <div class="meta">Pincode : ${esc(p.pincode)}</div>`
      : `<div class="meta">Date of Birth : ${esc(p.dateOfBirth)}</div>
         <div class="meta">Mobile No: ${esc(p.mobileNumber)}</div>
         <div class="meta">Speciality : ${esc(p.speciality)}</div>`;
    setView(`<div class="card dark profile">${avatar()}<div>
      <h2>${esc(p.name)}</h2><div class="id">${esc(isUser ? p.userId : p.coachId)}</div>${details}
      ${isUser ? '<a class="btn teal" href="#/user/home">&#8592; Go Back</a>' : ''}</div></div>`);
  }

  /* ------------------------------------------------------------ appointments (user) */
  async function appointments() {
    loading();
    const s = session.get();
    const list = (await api('GET', '/api/users/' + encodeURIComponent(s.id) + '/bookings')) || [];
    if (!list.length) {
      setView(`<div class="big-msg empty"><div class="illus">&#128221;</div>
        <h2>You haven't made any<br>appointments yet</h2>${goBack('#/user/home')}</div>`);
      return;
    }
    setView(`<div class="appt-grid">${list.map(b => `<div class="card dark appt">
        <h3>Appointment Date : ${esc(b.appointmentDate)}</h3><p class="slot">Slot: ${esc(b.slot)}</p>
        <p class="small">Booking id : ${esc(b.bookingId)}<br>User Id : ${esc(b.userId)}<br>Coach Id : ${esc(b.coachId)}</p>
        <a class="btn teal" href="#/user/reschedule/${b.bookingId}">Reschedule Appointment</a>
        <button class="btn red" type="button" data-cancel="${b.bookingId}">Cancel Appointment</button></div>`).join('')}</div>
      ${goBack('#/user/home')}`);
    view.querySelectorAll('[data-cancel]').forEach(btn =>
      btn.addEventListener('click', () => confirmCancel(btn.getAttribute('data-cancel'))));
  }

  function confirmCancel(bookingId) {
    modal.innerHTML = `<div class="dialog"><p>Are you sure you need to cancel the appointment?</p>
      <div><button class="btn green" type="button" id="yes">Yes</button><button class="btn red" type="button" id="no">No</button></div></div>`;
    modal.classList.remove('hidden');
    document.getElementById('no').addEventListener('click', closeModal);
    document.getElementById('yes').addEventListener('click', async () => {
      closeModal();
      try {
        await api('POST', '/api/bookings/' + encodeURIComponent(bookingId) + '/cancel');
        showMessage('Your appointment is cancelled successfully and you will receive an email to your registered Email Id soon', '#/user/appointments');
      } catch (err) {
        showMessage(err.message, '#/user/appointments');
      }
    });
  }

  /* ------------------------------------------------------------ book / reschedule */
  function slotForm(title, button, submit) {
    const today = new Date();
    const min = iso(today), max = iso(addDays(today, 7));
    setView(`<form class="card dark form-narrow" id="slotForm" novalidate>
      <h2><span class="ico">&#128221;</span>${title}</h2>
      <label for="apptDate">Date of Appointment</label>
      <input id="apptDate" name="date" type="date" min="${min}" max="${max}">
      <span class="err" data-for="date"></span>
      <label>Preferred Slot</label>
      <div class="slots">${SLOTS.map(s => `<label class="slot-opt"><input type="radio" name="slot" value="${s}"> ${s}</label>`).join('')}</div>
      <span class="err" data-for="slot"></span>
      <div class="form-actions"><button class="btn green" type="submit">${button}</button></div>
      <p class="err form-err" id="formErr"></p></form>`);

    const form = document.getElementById('slotForm');
    const setErr = (k, m) => { form.querySelector(`.err[data-for="${k}"]`).textContent = m; };
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const date = val(form, 'date'), slot = val(form, 'slot');
      const dErr = !date ? 'Please choose a date' : (date < min || date > max) ? 'Choose a date within the next 7 days' : '';
      const sErr = slot ? '' : 'Please choose a slot';
      setErr('date', dErr); setErr('slot', sErr);
      document.getElementById('formErr').textContent = '';
      if (dErr || sErr) return;
      const btn = form.querySelector('button');
      btn.disabled = true;
      try {
        await submit(date, slot);
      } catch (err) {
        document.getElementById('formErr').textContent = err.message;
        btn.disabled = false;
      }
    });
  }

  function bookForm(coachId) {
    const s = session.get();
    slotForm('Proceed with your Appointment', 'Confirm your Appointment', async (date, slot) => {
      await api('POST', '/api/bookings', { userId: s.id, coachId: coachId, appointmentDate: date, slot: slot });
      showMessage('Your appointment is scheduled successfully and you will receive an email to your registered Email Id soon', '#/user/home');
    });
  }

  function rescheduleForm(bookingId) {
    slotForm('Reschedule your Appointment', 'Reschedule your Appointment', async (date, slot) => {
      await api('POST', '/api/bookings/' + encodeURIComponent(bookingId) + '/reschedule', { appointmentDate: date, slot: slot });
      showMessage('Your appointment is rescheduled successfully and you will receive an email to your registered Email Id soon', '#/user/appointments');
    });
  }

  /* ------------------------------------------------------------ coach schedule */
  async function coachSchedule() {
    loading();
    const s = session.get();
    const list = (await api('GET', '/api/coaches/' + encodeURIComponent(s.id) + '/bookings')) || [];
    if (!list.length) {
      setView('<div class="big-msg empty"><div class="illus">&#128221;</div><h2>No planned schedules yet</h2></div>');
      return;
    }
    setView(`<div class="appt-grid">${list.map(b => `<div class="card dark appt">
      <h3>Appointment Date : ${esc(b.appointmentDate)}</h3><p class="slot">Slot: ${esc(b.slot)}</p>
      <p class="small">Booking id : ${esc(b.bookingId)}<br>User Id : ${esc(b.userId)}</p></div>`).join('')}</div>`);
  }

  /* ------------------------------------------------------------ start */
  window.addEventListener('hashchange', route);
  route();
})();
