package com.infosys.utility;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.concurrent.atomic.AtomicInteger;

import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.IdentifierGenerator;

public class UserIdGenerator implements IdentifierGenerator {
	private static final AtomicInteger counter = new AtomicInteger(1001);

	@Override
	public Serializable generate(SharedSessionContractImplementor session, Object object) {
		int id = counter.getAndIncrement();
		LocalDateTime now = LocalDateTime.now();
		String value = "U" + now.getDayOfMonth() + now.getMonthValue() + now.getYear() + now.getHour()
				+ now.getMinute();
		return value + id;
	}
}
