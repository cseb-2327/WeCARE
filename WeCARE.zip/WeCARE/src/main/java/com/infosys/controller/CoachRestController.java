package com.infosys.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.BookingDTO;
import com.infosys.dto.CoachDTO;
import com.infosys.dto.LoginDTO;
import com.infosys.exception.WecareException;
import com.infosys.service.BookService;
import com.infosys.service.CoachService;

@RestController
@RequestMapping("/api/coaches")
@CrossOrigin
public class CoachRestController {

	@Autowired
	private CoachService coachService;

	@Autowired
	private BookService bookService;

	// sign up -> returns the generated coach id
	@PostMapping
	public String createCoach(@Valid @RequestBody CoachDTO coachDTO) {
		return coachService.createCoach(coachDTO);
	}

	// login -> true when the password matches
	@PostMapping("/login")
	public boolean loginCoach(@RequestBody LoginDTO loginDTO) throws WecareException {
		return coachService.loginCoach(loginDTO);
	}

	// list of all life coaches
	@GetMapping
	public List<CoachDTO> showAllCoaches() {
		return coachService.showAllCoaches();
	}

	// view profile
	@GetMapping("/{coachId}")
	public CoachDTO getCoachProfile(@PathVariable String coachId) {
		return coachService.getCoachProfile(coachId);
	}

	// view upcoming schedule of a coach
	@GetMapping("/{coachId}/bookings")
	public List<BookingDTO> findBookingByCoachId(@PathVariable String coachId) {
		return bookService.findBookingByCoachId(coachId);
	}
}
