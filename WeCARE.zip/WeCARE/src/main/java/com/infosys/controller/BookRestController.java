package com.infosys.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.BookingDTO;
import com.infosys.exception.WecareException;
import com.infosys.service.BookService;

@RestController
@RequestMapping("/api/bookings")
@CrossOrigin
public class BookRestController {

	@Autowired
	private BookService bookService;

	// book an appointment
	@PostMapping
	public boolean bookAppointment(@RequestBody BookingDTO bookingDTO) throws WecareException {
		return bookService.bookAppointment(bookingDTO.getUserId(), bookingDTO.getCoachId(),
				bookingDTO.getAppointmentDate(), bookingDTO.getSlot());
	}

	// reschedule an appointment
	@PostMapping("/{bookingId}/reschedule")
	public boolean rescheduleAppointment(@PathVariable Integer bookingId, @RequestBody BookingDTO bookingDTO)
			throws WecareException {
		return bookService.rescheduleAppointment(bookingId, bookingDTO.getAppointmentDate(), bookingDTO.getSlot());
	}

	// cancel an appointment
	@PostMapping("/{bookingId}/cancel")
	public void cancelAppointment(@PathVariable Integer bookingId) throws WecareException {
		bookService.cancelAppointment(bookingId);
	}

	// find one appointment
	@GetMapping("/{bookingId}")
	public BookingDTO findByBookingId(@PathVariable Integer bookingId) throws WecareException {
		return bookService.findByBookingId(bookingId);
	}
}
