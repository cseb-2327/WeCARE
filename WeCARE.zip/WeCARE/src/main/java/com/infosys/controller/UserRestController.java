package com.infosys.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.dto.BookingDTO;
import com.infosys.dto.LoginDTO;
import com.infosys.dto.UserDTO;
import com.infosys.exception.WecareException;
import com.infosys.service.BookService;
import com.infosys.service.UserService;

@RestController
@RequestMapping("/api/users")
@CrossOrigin
public class UserRestController {

	@Autowired
	private UserService userService;

	@Autowired
	private BookService bookService;

	// sign up -> returns the generated user id
	@PostMapping
	public String createUser(@Valid @RequestBody UserDTO userDTO) {
		return userService.createUser(userDTO);
	}

	// login -> true when the password matches
	@PostMapping("/login")
	public boolean loginUser(@RequestBody LoginDTO loginDTO) throws WecareException {
		return userService.loginUser(loginDTO);
	}

	// view profile
	@GetMapping("/{userId}")
	public UserDTO getUserProfile(@PathVariable String userId) {
		return userService.getUserProfile(userId);
	}

	// view upcoming appointments of a user
	@GetMapping("/{userId}/bookings")
	public List<BookingDTO> findBookingByUserId(@PathVariable String userId) {
		return bookService.findBookingByUserId(userId);
	}
}
