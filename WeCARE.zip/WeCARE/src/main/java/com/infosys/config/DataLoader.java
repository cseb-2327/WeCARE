package com.infosys.config;

import java.time.LocalDate;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.infosys.entity.BookingEntity;
import com.infosys.entity.CoachEntity;
import com.infosys.entity.UserEntity;
import com.infosys.repository.BookRepository;
import com.infosys.repository.CoachRepository;
import com.infosys.repository.UserRepository;

/**
 * Puts some default data in the database the first time the application starts (only when the tables are
 * empty). Ids come from the time based id generators and the appointment dates are calculated from today's date,
 * so there are always upcoming appointments to look at.
 */
@Component
public class DataLoader implements CommandLineRunner {

	private static final Logger LOGGER = LoggerFactory.getLogger(DataLoader.class);

	@Autowired
	private CoachRepository coachRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private BookRepository bookRepository;

	@Value("${wecare.seed.enabled:true}")
	private boolean seedEnabled;

	@Override
	public void run(String... args) {
		if (!seedEnabled) {
			return;
		}
		if (coachRepository.count() > 0 || userRepository.count() > 0) {
			LOGGER.info("Database already has data - default data not inserted.");
			return;
		}

		LocalDate today = LocalDate.now();

		String neha = coach("Neha", 'F', LocalDate.of(1999, 3, 7), 9876543210L, "Anxiety Specialist");
		String yuvraj = coach("Yuvraj", 'M', LocalDate.of(1990, 1, 1), 1234567890L, "Happiness Issue");
		String narendar = coach("Narendar", 'M', LocalDate.of(1988, 7, 19), 9999999999L, "Anxiety Issue");
		coach("Priya", 'F', LocalDate.of(1992, 6, 15), 9812345670L, "Career Guidance");
		coach("Rahul", 'M', LocalDate.of(1987, 9, 21), 9823456701L, "Stress Management");
		coach("Anjali", 'F', LocalDate.of(1985, 12, 2), 9834567012L, "Relationship Coach");

		String abhishek = user("Abhishek", 'M', LocalDate.of(1995, 11, 28), 9464927770L, "abhishek@example.com",
				160020, "Chandigarh", "Chandigarh", "India");
		String abhi = user("Abhi", 'M', LocalDate.of(2000, 1, 1), 1231231231L, "abhi@example.com", 123456, "Panaji",
				"Goa", "India");

		booking(abhishek, neha, today.plusDays(1), "3 PM to 4 PM");
		booking(abhishek, yuvraj, today.plusDays(4), "11 AM to 12 PM");
		booking(abhi, yuvraj, today.plusDays(2), "9 AM to 10 AM");
		booking(abhi, narendar, today.plusDays(2), "10 AM to 11 AM");

		LOGGER.info("==================== WeCARE demo logins (password for all: 12345) ====================");
		LOGGER.info("User  : {}  (Abhishek)", abhishek);
		LOGGER.info("User  : {}  (Abhi)", abhi);
		LOGGER.info("Coach : {}  (Neha)", neha);
		LOGGER.info("Coach : {}  (Yuvraj)", yuvraj);
		LOGGER.info("Coach : {}  (Narendar)", narendar);
		LOGGER.info("=====================================================================================");
	}

	private String coach(String name, char gender, LocalDate dob, long mobile, String speciality) {
		CoachEntity c = new CoachEntity();
		c.setName(name);
		c.setPassword("12345");
		c.setGender(gender);
		c.setDateOfBirth(dob);
		c.setMobileNumber(mobile);
		c.setSpeciality(speciality);
		return coachRepository.save(c).getCoachId();
	}

	private String user(String name, char gender, LocalDate dob, long mobile, String email, int pincode, String city,
			String state, String country) {
		UserEntity u = new UserEntity();
		u.setName(name);
		u.setPassword("12345");
		u.setGender(gender);
		u.setDateOfBirth(dob);
		u.setMobileNumber(mobile);
		u.setEmail(email);
		u.setPincode(pincode);
		u.setCity(city);
		u.setState(state);
		u.setCountry(country);
		return userRepository.save(u).getUserId();
	}

	private void booking(String userId, String coachId, LocalDate date, String slot) {
		BookingEntity b = new BookingEntity();
		b.setUserId(userId);
		b.setCoachId(coachId);
		b.setAppointmentDate(date);
		b.setSlot(slot);
		bookRepository.save(b);
	}
}
