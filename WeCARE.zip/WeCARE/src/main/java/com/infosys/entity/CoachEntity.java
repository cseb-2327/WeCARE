package com.infosys.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "coachtable")
public class CoachEntity {

	@Id
	@GenericGenerator(name = "coachIdGenerator", strategy = "com.infosys.utility.CoachIdGenerator")
	@GeneratedValue(generator = "coachIdGenerator")
	@Column(name = "coach_id")
	private String coachId;

	@Column(name = "name")
	private String name;

	@Column(name = "password")
	private String password;

	@Column(name = "gender")
	private char gender;

	@Column(name = "date_of_birth")
	private LocalDate dateOfBirth;

	@Column(name = "mobile_number")
	private long mobileNumber;

	@Column(name = "speciality")
	private String speciality;

	public String getCoachId() { return coachId; }
	public void setCoachId(String coachId) { this.coachId = coachId; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	public char getGender() { return gender; }
	public void setGender(char gender) { this.gender = gender; }
	public LocalDate getDateOfBirth() { return dateOfBirth; }
	public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
	public long getMobileNumber() { return mobileNumber; }
	public void setMobileNumber(long mobileNumber) { this.mobileNumber = mobileNumber; }
	public String getSpeciality() { return speciality; }
	public void setSpeciality(String speciality) { this.speciality = speciality; }
}
