package com.infosys.dto;

import java.time.LocalDate;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class UserDTO {
	private String userId;

	@NotNull(message = "Password cannot be null")
	@Size(min = 5, max = 10, message = "Password length should be between 5 and 10 characters")
	private String password;

	@NotNull(message = "Name cannot be null")
	@Size(min = 3, max = 50, message = "Name length should be between 3 and 50 characters")
	private String name;

	private LocalDate dateOfBirth;

	private char gender;

	@Min(value = 1000000000L, message = "Mobile number should be exactly 10 digits")
	@Max(value = 9999999999L, message = "Mobile number should be exactly 10 digits")
	private long mobileNumber;

	@NotNull(message = "Email cannot be null")
	@Email(message = "Please enter a valid email")
	private String email;

	@Min(value = 100000, message = "Pincode should be exactly 6 digits")
	@Max(value = 999999, message = "Pincode should be exactly 6 digits")
	private int pincode;

	@NotNull(message = "City cannot be null")
	@Size(min = 3, max = 20, message = "City length should be between 3 and 20 characters")
	private String city;

	@NotNull(message = "State cannot be null")
	@Size(min = 3, max = 20, message = "State length should be between 3 and 20 characters")
	private String state;

	@NotNull(message = "Country cannot be null")
	@Size(min = 3, max = 20, message = "Country length should be between 3 and 20 characters")
	private String country;

	public String getUserId() { return userId; }
	public void setUserId(String userId) { this.userId = userId; }
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public LocalDate getDateOfBirth() { return dateOfBirth; }
	public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
	public char getGender() { return gender; }
	public void setGender(char gender) { this.gender = gender; }
	public long getMobileNumber() { return mobileNumber; }
	public void setMobileNumber(long mobileNumber) { this.mobileNumber = mobileNumber; }
	public String getEmail() { return email; }
	public void setEmail(String email) { this.email = email; }
	public int getPincode() { return pincode; }
	public void setPincode(int pincode) { this.pincode = pincode; }
	public String getCity() { return city; }
	public void setCity(String city) { this.city = city; }
	public String getState() { return state; }
	public void setState(String state) { this.state = state; }
	public String getCountry() { return country; }
	public void setCountry(String country) { this.country = country; }
}
