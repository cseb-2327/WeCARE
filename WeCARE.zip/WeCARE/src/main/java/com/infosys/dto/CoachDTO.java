package com.infosys.dto;

import java.time.LocalDate;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class CoachDTO {
	private String coachId;

	@NotNull(message = "Password cannot be null")
	@Size(min = 5, max = 10, message = "Password length should be between 5 and 10 characters")
	private String password;

	@NotNull(message = "Name cannot be null")
	@Size(min = 3, max = 50, message = "Name length should be between 3 and 50 characters")
	private String name;

	private LocalDate dateOfBirth;

	private char gender;

	@Min(value = 1000000000L, message = "Mobile number should be exactly 10 digits")
	@Max(value = 9999999999L, message = "Mobile number should be exactly 10 digits")
	private long mobileNumber;

	@NotNull(message = "Speciality cannot be null")
	@Size(min = 3, max = 50, message = "Speciality length should be between 3 and 50 characters")
	private String speciality;

	public String getCoachId() { return coachId; }
	public void setCoachId(String coachId) { this.coachId = coachId; }
	public String getPassword() { return password; }
	public void setPassword(String password) { this.password = password; }
	public String getName() { return name; }
	public void setName(String name) { this.name = name; }
	public LocalDate getDateOfBirth() { return dateOfBirth; }
	public void setDateOfBirth(LocalDate dateOfBirth) { this.dateOfBirth = dateOfBirth; }
	public char getGender() { return gender; }
	public void setGender(char gender) { this.gender = gender; }
	public long getMobileNumber() { return mobileNumber; }
	public void setMobileNumber(long mobileNumber) { this.mobileNumber = mobileNumber; }
	public String getSpeciality() { return speciality; }
	public void setSpeciality(String speciality) { this.speciality = speciality; }
}
