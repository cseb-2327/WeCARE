package com.infosys.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.dto.LoginDTO;
import com.infosys.dto.UserDTO;
import com.infosys.entity.UserEntity;
import com.infosys.exception.ExceptionConstants;
import com.infosys.exception.WecareException;
import com.infosys.repository.UserRepository;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepository;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public String createUser(UserDTO userDTO) {
		logger.info("Inside createUser() method of {}", this.getClass());
		UserEntity userEntity = new UserEntity();
		userEntity.setName(userDTO.getName());
		userEntity.setPassword(userDTO.getPassword());
		userEntity.setGender(userDTO.getGender());
		userEntity.setDateOfBirth(userDTO.getDateOfBirth());
		userEntity.setMobileNumber(userDTO.getMobileNumber());
		userEntity.setEmail(userDTO.getEmail());
		userEntity.setPincode(userDTO.getPincode());
		userEntity.setCity(userDTO.getCity());
		userEntity.setState(userDTO.getState());
		userEntity.setCountry(userDTO.getCountry());
		return userRepository.save(userEntity).getUserId();
	}

	public boolean loginUser(LoginDTO loginDTO) throws WecareException {
		logger.info("Inside loginUser() method of {}", this.getClass());
		UserEntity userEntity = userRepository.findByUserId(loginDTO.getId())
				.orElseThrow(() -> new WecareException(ExceptionConstants.USER_NOT_FOUND.toString()));
		return userEntity.getPassword() != null && userEntity.getPassword().equals(loginDTO.getPassword());
	}

	public UserDTO getUserProfile(String userId) {
		logger.info("Inside getUserProfile() method of {}", this.getClass());
		return userRepository.findByUserId(userId).map(this::toDTO).orElse(null);
	}

	// the password is never sent back to the browser
	private UserDTO toDTO(UserEntity entity) {
		UserDTO dto = new UserDTO();
		dto.setUserId(entity.getUserId());
		dto.setName(entity.getName());
		dto.setGender(entity.getGender());
		dto.setDateOfBirth(entity.getDateOfBirth());
		dto.setMobileNumber(entity.getMobileNumber());
		dto.setEmail(entity.getEmail());
		dto.setPincode(entity.getPincode());
		dto.setCity(entity.getCity());
		dto.setState(entity.getState());
		dto.setCountry(entity.getCountry());
		return dto;
	}
}
