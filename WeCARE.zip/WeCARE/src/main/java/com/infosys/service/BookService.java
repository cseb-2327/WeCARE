package com.infosys.service;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.dto.BookingDTO;
import com.infosys.entity.BookingEntity;
import com.infosys.entity.CoachEntity;
import com.infosys.entity.UserEntity;
import com.infosys.exception.ExceptionConstants;
import com.infosys.exception.WecareException;
import com.infosys.repository.BookRepository;
import com.infosys.repository.CoachRepository;
import com.infosys.repository.UserRepository;
import com.infosys.utility.MailUtility;

@Service
@Transactional
public class BookService {

	private static final List<String> SLOTS = Arrays.asList("9 AM to 10 AM", "10 AM to 11 AM", "11 AM to 12 PM",
			"2 PM to 3 PM", "3 PM to 4 PM", "4 PM to 5 PM");

	@Autowired
	private BookRepository bookRepository;

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private CoachRepository coachRepository;

	@Autowired
	private MailUtility mailUtility;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public boolean bookAppointment(String userId, String coachId, LocalDate appointmentDate, String slot)
			throws WecareException {
		logger.info("Inside bookAppointment() method of {}", this.getClass());
		UserEntity user = findUser(userId);
		CoachEntity coach = findCoach(coachId);
		if (bookRepository.findAllBookings(userId, appointmentDate, slot) != null) {
			throw new WecareException(ExceptionConstants.BOOKING_ALREADY_EXISTS.toString());
		}
		BookingEntity bookingEntity = new BookingEntity();
		bookingEntity.setUserId(userId);
		bookingEntity.setCoachId(coachId);
		bookingEntity.setAppointmentDate(appointmentDate);
		bookingEntity.setSlot(slot);
		bookingEntity = bookRepository.save(bookingEntity);
		mailUtility.sendSchedulingEmail(user.getName(), coach.getName(), user.getEmail(), bookingEntity.getBookingId(),
				slot, appointmentDate);
		return true;
	}

	public boolean rescheduleAppointment(Integer bookingId, LocalDate appointmentDate, String slot)
			throws WecareException {
		logger.info("Inside rescheduleAppointment() method of {}", this.getClass());
		BookingEntity bookingEntity = findBooking(bookingId);
		if (bookRepository.findAllBookings(bookingEntity.getUserId(), appointmentDate, slot) != null) {
			throw new WecareException(ExceptionConstants.BOOKING_ALREADY_EXISTS.toString());
		}
		UserEntity user = findUser(bookingEntity.getUserId());
		CoachEntity coach = findCoach(bookingEntity.getCoachId());
		bookingEntity.setAppointmentDate(appointmentDate);
		bookingEntity.setSlot(slot);
		bookingEntity = bookRepository.save(bookingEntity);
		mailUtility.sendReschedulingEmail(user.getName(), coach.getName(), user.getEmail(),
				bookingEntity.getBookingId(), slot, appointmentDate);
		return true;
	}

	public void cancelAppointment(Integer bookingId) throws WecareException {
		logger.info("Inside cancelAppointment() method of {}", this.getClass());
		BookingEntity bookingEntity = findBooking(bookingId);
		UserEntity user = findUser(bookingEntity.getUserId());
		CoachEntity coach = findCoach(bookingEntity.getCoachId());
		bookRepository.deleteById(bookingId);
		mailUtility.sendCancellingEmail(user.getName(), coach.getName(), user.getEmail(), bookingEntity.getBookingId(),
				bookingEntity.getSlot(), bookingEntity.getAppointmentDate());
	}

	public BookingDTO findByBookingId(Integer bookingId) throws WecareException {
		logger.info("Inside findByBookingId() method of {}", this.getClass());
		return toDTO(findBooking(bookingId));
	}

	public List<BookingDTO> findBookingByUserId(String userId) {
		logger.info("Inside findBookingByUserId() method of {}", this.getClass());
		return toSortedDTOs(bookRepository.findBookingByUserId(userId, LocalDate.now()));
	}

	public List<BookingDTO> findBookingByCoachId(String coachId) {
		logger.info("Inside findBookingByCoachId() method of {}", this.getClass());
		return toSortedDTOs(bookRepository.findBookingByCoachId(coachId, LocalDate.now()));
	}

	private BookingEntity findBooking(Integer bookingId) throws WecareException {
		return bookRepository.findById(bookingId)
				.orElseThrow(() -> new WecareException(ExceptionConstants.BOOKING_NOT_FOUND.toString()));
	}

	private UserEntity findUser(String userId) throws WecareException {
		return userRepository.findByUserId(userId)
				.orElseThrow(() -> new WecareException(ExceptionConstants.USER_NOT_FOUND.toString()));
	}

	private CoachEntity findCoach(String coachId) throws WecareException {
		return coachRepository.findByCoachId(coachId)
				.orElseThrow(() -> new WecareException(ExceptionConstants.COACH_NOT_FOUND.toString()));
	}

	private List<BookingDTO> toSortedDTOs(List<BookingEntity> bookings) {
		return bookings.stream()
				.sorted(Comparator.comparing(BookingEntity::getAppointmentDate)
						.thenComparingInt(b -> SLOTS.indexOf(b.getSlot())))
				.map(this::toDTO).collect(Collectors.toList());
	}

	private BookingDTO toDTO(BookingEntity entity) {
		BookingDTO dto = new BookingDTO();
		dto.setBookingId(entity.getBookingId());
		dto.setUserId(entity.getUserId());
		dto.setCoachId(entity.getCoachId());
		dto.setAppointmentDate(entity.getAppointmentDate());
		dto.setSlot(entity.getSlot());
		return dto;
	}
}
