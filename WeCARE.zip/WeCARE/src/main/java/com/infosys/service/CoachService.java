package com.infosys.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.dto.CoachDTO;
import com.infosys.dto.LoginDTO;
import com.infosys.entity.CoachEntity;
import com.infosys.exception.ExceptionConstants;
import com.infosys.exception.WecareException;
import com.infosys.repository.CoachRepository;

@Service
@Transactional
public class CoachService {

	@Autowired
	private CoachRepository coachRepository;

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	public String createCoach(CoachDTO coachDTO) {
		logger.info("Inside createCoach() method of {}", this.getClass());
		CoachEntity coachEntity = new CoachEntity();
		coachEntity.setName(coachDTO.getName());
		coachEntity.setPassword(coachDTO.getPassword());
		coachEntity.setGender(coachDTO.getGender());
		coachEntity.setDateOfBirth(coachDTO.getDateOfBirth());
		coachEntity.setMobileNumber(coachDTO.getMobileNumber());
		coachEntity.setSpeciality(coachDTO.getSpeciality());
		return coachRepository.save(coachEntity).getCoachId();
	}

	public boolean loginCoach(LoginDTO loginDTO) throws WecareException {
		logger.info("Inside loginCoach() method of {}", this.getClass());
		CoachEntity coachEntity = coachRepository.findByCoachId(loginDTO.getId())
				.orElseThrow(() -> new WecareException(ExceptionConstants.COACH_NOT_FOUND.toString()));
		return coachEntity.getPassword() != null && coachEntity.getPassword().equals(loginDTO.getPassword());
	}

	public CoachDTO getCoachProfile(String coachId) {
		logger.info("Inside getCoachProfile() method of {}", this.getClass());
		return coachRepository.findByCoachId(coachId).map(this::toDTO).orElse(null);
	}

	public List<CoachDTO> showAllCoaches() {
		logger.info("Inside showAllCoaches() method of {}", this.getClass());
		return coachRepository.findAll().stream().map(this::toDTO).collect(Collectors.toList());
	}

	// the password is never sent back to the browser
	private CoachDTO toDTO(CoachEntity entity) {
		CoachDTO dto = new CoachDTO();
		dto.setCoachId(entity.getCoachId());
		dto.setName(entity.getName());
		dto.setGender(entity.getGender());
		dto.setDateOfBirth(entity.getDateOfBirth());
		dto.setMobileNumber(entity.getMobileNumber());
		dto.setSpeciality(entity.getSpeciality());
		return dto;
	}
}
