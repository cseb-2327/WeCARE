@echo off
REM Runs WeCARE on Windows.   run.bat        -> no MySQL needed (default)
REM                          run.bat mysql  -> uses your MySQL
setlocal
cd /d "%~dp0"
set "PROFILE=%~1"
if "%PROFILE%"=="" set "PROFILE=h2"
set "MVN_VERSION=3.9.6"

where javac >nul 2>nul
if not errorlevel 1 goto javaok
if defined JAVA_HOME if exist "%JAVA_HOME%\bin\javac.exe" goto javaok
echo.
echo A Java JDK 8 or newer is required but javac was not found.
echo Install the free Temurin JDK 17 from https://adoptium.net and run this file again.
pause
exit /b 1

:javaok
set "MVN=mvn"
where mvn >nul 2>nul
if not errorlevel 1 goto run

set "MVN_HOME=%~dp0.tools\apache-maven-%MVN_VERSION%"
if exist "%MVN_HOME%\bin\mvn.cmd" goto havemaven
echo Maven not found - downloading a private copy, one time only...
if not exist ".tools" mkdir ".tools"
powershell -NoProfile -ExecutionPolicy Bypass -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -UseBasicParsing 'https://archive.apache.org/dist/maven/maven-3/%MVN_VERSION%/binaries/apache-maven-%MVN_VERSION%-bin.zip' -OutFile '.tools\maven.zip'; Expand-Archive -Force '.tools\maven.zip' '.tools'"
if errorlevel 1 goto mvnfail
del ".tools\maven.zip" >nul 2>nul

:havemaven
set "MVN=%MVN_HOME%\bin\mvn.cmd"
goto run

:mvnfail
echo Could not download Maven. Check your internet connection or install Maven yourself.
pause
exit /b 1

:run
echo Starting WeCARE with profile %PROFILE% - open http://localhost:52866 when you see Started WeCareApplication
if /i "%PROFILE%"=="h2" goto runh2
call "%MVN%" spring-boot:run
goto end

:runh2
call "%MVN%" spring-boot:run -Dspring-boot.run.profiles=h2

:end
pause
