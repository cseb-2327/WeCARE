#!/usr/bin/env bash
# Runs WeCARE on Linux / macOS.   ./run.sh        -> no MySQL needed (default)
#                                 ./run.sh mysql  -> uses your MySQL
set -e
cd "$(dirname "$0")"
PROFILE="${1:-h2}"
MVN_VERSION=3.9.6

if ! command -v javac >/dev/null 2>&1; then
  echo "A Java JDK (8 or newer) is required but 'javac' was not found."
  echo "Install the free Temurin JDK 17 from https://adoptium.net and run this script again."
  exit 1
fi

if command -v mvn >/dev/null 2>&1; then
  MVN=mvn
else
  MVN_HOME=".tools/apache-maven-$MVN_VERSION"
  if [ ! -x "$MVN_HOME/bin/mvn" ]; then
    echo "Maven not found - downloading a private copy (one time only)..."
    mkdir -p .tools
    URL="https://archive.apache.org/dist/maven/maven-3/$MVN_VERSION/binaries/apache-maven-$MVN_VERSION-bin.tar.gz"
    if command -v curl >/dev/null 2>&1; then
      curl -fsSL "$URL" -o .tools/maven.tar.gz
    elif command -v wget >/dev/null 2>&1; then
      wget -q "$URL" -O .tools/maven.tar.gz
    else
      echo "Please install curl or wget (or Maven itself) and try again."; exit 1
    fi
    tar -xzf .tools/maven.tar.gz -C .tools
    rm -f .tools/maven.tar.gz
  fi
  MVN="$MVN_HOME/bin/mvn"
fi

echo "Starting WeCARE (profile: $PROFILE) - open http://localhost:52866 when you see 'Started WeCareApplication'"
if [ "$PROFILE" = "h2" ]; then
  exec "$MVN" spring-boot:run -Dspring-boot.run.profiles=h2
else
  exec "$MVN" spring-boot:run
fi
